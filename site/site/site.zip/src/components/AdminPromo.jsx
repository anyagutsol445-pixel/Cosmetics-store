import React, { useState, useEffect } from 'react';

const API = 'http://localhost:5000';

const AdminPromo = ({ user, showToast }) => {
    const [promos, setPromos] = useState([]);
    const [form, setForm] = useState({ code: '', discount_percent: '', max_uses: '', expires_at: '' });
    const [loading, setLoading] = useState(false);

    const headers = { Authorization: 'Bearer ' + user?.token };

    const fetchPromos = async () => {
        try {
            const res = await fetch(API + '/api/admin/promo', { headers });
            const data = await res.json();
            setPromos(Array.isArray(data) ? data : []);
        } catch { showToast('Помилка завантаження', 'error'); }
    };

    useEffect(() => { fetchPromos(); }, []);

    const handleAdd = async (e) => {
        e.preventDefault();
        if (!form.code || !form.discount_percent) { showToast('Код та відсоток обов\'язкові', 'error'); return; }
        setLoading(true);
        try {
            const res = await fetch(API + '/api/admin/promo', {
                method: 'POST',
                headers: { ...headers, 'Content-Type': 'application/json' },
                body: JSON.stringify(form)
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error);
            showToast('Промокод створено!');
            setForm({ code: '', discount_percent: '', max_uses: '', expires_at: '' });
            fetchPromos();
        } catch (err) { showToast(err.message, 'error'); }
        finally { setLoading(false); }
    };

    const handleDelete = async (id, code) => {
        if (!window.confirm('Видалити промокод "' + code + '"?')) return;
        try {
            await fetch(API + '/api/admin/promo/' + id, { method: 'DELETE', headers });
            showToast('Видалено');
            fetchPromos();
        } catch { showToast('Помилка', 'error'); }
    };

    return (
        <div className="admin-layout">
            <div className="admin-container">
                <h2>Створити промокод</h2>
                <form onSubmit={handleAdd} className="admin-form">
                    <label className="field-label">Код</label>
                    <input placeholder="SALE20" value={form.code}
                        onChange={e => setForm({...form, code: e.target.value.toUpperCase()})} required />
                    <label className="field-label">Знижка (%)</label>
                    <input type="number" placeholder="20" min="1" max="100" value={form.discount_percent}
                        onChange={e => setForm({...form, discount_percent: e.target.value})} required />
                    <div className="form-row">
                        <div>
                            <label className="field-label">Макс. використань</label>
                            <input type="number" placeholder="∞" min="1" value={form.max_uses}
                                onChange={e => setForm({...form, max_uses: e.target.value})} />
                        </div>
                        <div>
                            <label className="field-label">Діє до</label>
                            <input type="datetime-local" value={form.expires_at}
                                onChange={e => setForm({...form, expires_at: e.target.value})} />
                        </div>
                    </div>
                    <button type="submit" className="submit-btn" disabled={loading}>
                        {loading ? '...' : 'Створити промокод'}
                    </button>
                </form>
            </div>

            <div className="admin-products-section">
                <h2>Промокоди ({promos.length})</h2>
                {promos.length === 0 ? (
                    <div className="empty-state">Промокодів немає</div>
                ) : (
                    <div className="admin-products-grid">
                        {promos.map(p => (
                            <div key={p.id} className="admin-product-card">
                                <div style={{ flex: 1 }}>
                                    <div className="admin-product-title" style={{ fontSize: '1.05rem', letterSpacing: '0.05em' }}>{p.code}</div>
                                    <div className="admin-product-meta">
                                        <span className="stock-chip in-stock">−{p.discount_percent}%</span>
                                        <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                                            {p.uses_count}{p.max_uses ? '/' + p.max_uses : ''} використань
                                        </span>
                                        {p.expires_at && (
                                            <span style={{ color: 'var(--text-muted)', fontSize: '0.78rem' }}>
                                                до {new Date(p.expires_at).toLocaleDateString('uk-UA')}
                                            </span>
                                        )}
                                        <span className={p.is_active ? 'stock-chip in-stock' : 'stock-chip out-stock'}>
                                            {p.is_active ? 'Активний' : 'Вимкнено'}
                                        </span>
                                    </div>
                                </div>
                                <div className="admin-product-actions">
                                    <button className="delete-btn" onClick={() => handleDelete(p.id, p.code)}>Видалити</button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default AdminPromo;
